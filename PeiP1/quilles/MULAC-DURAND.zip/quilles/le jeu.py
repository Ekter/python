from masterpomme import *
from PQ import *

MasterPomme(0.4,0,0)
left(180)
PQ(0.4,200,0)
