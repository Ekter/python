from turtle import*

bgcolor("red")
