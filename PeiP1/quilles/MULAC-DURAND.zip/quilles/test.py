from turtle import *
screen=Screen()
tortuetest=Turtle()
while True:
    screen.onclick(tortuetest.goto)