a=1
while a<21:
    if a*(a|1) == 30:
        a=23
    else:
        a+=2
print(a)
