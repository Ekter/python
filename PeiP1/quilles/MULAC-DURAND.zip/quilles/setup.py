from turtle import *
def setup(x,y,angle,tortue):


    tortue.setheading(angle)


    tortue.up()
    tortue.goto(x,y)
    tortue.down()

    tracer(0)
