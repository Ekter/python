from turtle import *

cote = 5
forward(cote)
goto(cote/2,cote)
goto(0,0)
